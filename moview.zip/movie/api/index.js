
module.exports = {
    movie : require('./movie')
}