
module.exports={
    MovieRepository : require('./repository/movie-repository'),
    databaseConnection : require('./connection')
}