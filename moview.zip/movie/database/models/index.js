
module.exports = {
    MovieModel : require('./Info'),
    ActorModel : require('./Actor'),
    DirectorModel : require('./Director'),
    PlatformModel : require('./Platform')
}