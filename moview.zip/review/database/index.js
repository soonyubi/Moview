
module.exports={
    ReviewRepository : require('./repository/review-repository'),
    databaseConnection : require('./connection')
}