module.exports = {
    UserRepository : require('./repository/user-repository'),
    databaseConnection : require('./connection')
}