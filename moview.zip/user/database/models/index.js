module.exports = {
    UserModel : require('./User'),
    InterestModel : require('./Interest')
}